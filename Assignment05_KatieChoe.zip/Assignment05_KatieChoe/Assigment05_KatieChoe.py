#-------------------------------------------------#
# Title: Working with Dictionaries
# Dev:   KChoe
# Date:  May 8, 2017
# ChangeLog: (Who, When, What)
#   RRoot, 11/02/2016, Created starting template
#   KChoe, 05/08/2017, Added code to complete assignment 5
#https://www.tutorialspoint.com/python/python_dictionary.htm
#-------------------------------------------------#

#-- Data --#
# declare variables and constants
# objFile = An object that represents a file
# strData = A row of text data from the file
# dicRow = A row of data separated into elements of a dictionary {Task,Priority}
# lstTable = A dictionary that acts as a 'table' of rows
# strMenu = A menu of user options
# strChoice = Capture the user option selection

#-- Input/Output --#
# User can see a Menu (Step 2)
# User can see data (Step 3)
# User can insert or delete data(Step 4 and 5)
# User can save to file (Step 6)

#-- Processing --#
# Step 1
# When the program starts, load the any data you have
# in a text file called ToDo.txt into a python Dictionary.

# Step 2
# Display a menu of choices to the user

# Step 3
# Display all todo items to user

# Step 4
# Add a new item to the list/Table

# Step 5
# Remove a new item to the list/Table

# Step 6
# Save tasks to the ToDo.txt file

# Step 7
# Exit program
#-------------------------------
#-- Data --#
objFileName = "C:\_PythonClass\ToDo.txt"
oldData = "" #empty str to read data from file
dicRow = {} #A row of data separated into elements of a dictionary {Task,Priority}
lstTable = [] #A dictionary that acts as a 'table' of rows

#-- Input/Output --#


# Step 1
    # When the program starts, load the any data you have
    # in a text file called ToDo.txt into a python Dictionary.

with open(objFileName, "r") as objFile:
    for line in objFile:
        t, p = line.rstrip('\n').split(",")
        lstTable.append({"Task": t, "Priority": p})

print(type(lstTable))
# Step 2 - Display a menu of choices to the user
while(True):
    print ("""
    Menu of Options
    1) Show current data
    2) Add a new item.
    3) Remove an existing item.
    4) Save Data to File
    5) Exit Program
    """)
    strChoice = str(input("Which option would you like to perform? [1 to 4] - "))
    print()#adding a new line


# Step 3 -Show the current items in the table
    if (strChoice.strip() == '1'):
        print("Your To-Do List: ")
        for eachRow in lstTable:
            print('{Task}, {Priority}'.format(**eachRow))

    # Step 4 - Add a new item to the list/Table
    elif(strChoice.strip() == '2'):
        #getting inputs
        task = input("Enter Task: ")
        priority = input("Enter Priority (low, median or high): ").lower()
        #check to make sure user input priority correctly
        while priority not in ['low', 'high', 'median']:
            priority = input("Priority has to be either low, median or high, please re-enter: ").lower()
        #append the new input into the list
        lstTable.append({"Task": task, "Priority": priority})
        print("New Task Added!")

    # Step 5 - Remove a item to the list/Table
    elif(strChoice == '3'):
        #print all task with assigned number for user to choose
        for idx, eachRow in enumerate(lstTable):
            print(idx, '{Task}, {Priority}'.format(**eachRow))
        removeTask = int(input("Enter Task Number to remove: "))
        #make sure user choose an existing number
        while removeTask >= len(lstTable):
            removeTask = int(input("Task number don't exist, please re-enter: "))
        #remove that task from dictionary
        lstTable.pop(removeTask)
        print("Task Number: " + str(removeTask) + " Removed!")

    # Step 6 - Save tasks to the ToDo.txt file
    elif(strChoice == '4'):
        objFileSave = open(objFileName, "w")
        for eachRow in lstTable:
            objFileSave.write('{Task}, {Priority}\n'.format(**eachRow))
        objFileSave.close()
        print("All Data Saved!")


    elif (strChoice == '5'):
        break #and Exit the program

